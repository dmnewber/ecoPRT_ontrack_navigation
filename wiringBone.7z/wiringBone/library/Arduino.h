
// Dummy file

#ifndef ARDUINO_H
#define ARDUINO_H

#include "Wiring.h"

#endif
