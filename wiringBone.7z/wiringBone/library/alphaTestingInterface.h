#ifndef ALPHATEST
#define ALPHATEST

void testingInterface(void);

#endif
